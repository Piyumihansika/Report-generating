import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as jsPDF from 'jspdf';
import { Options } from 'selenium-webdriver/ie';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {
  
 @ViewChild('content',{static: false}) content :ElementRef;

public downloadPDF(){
let doc =new jsPDF();
let specialElementHandlers ={
'#editor': function(element,renderer){
  return true;

}
};
let content = this.content.nativeElement;
doc.fromHTML(content.innerHTML,15,15,{
'width':190,
'elementHAndlers':specialElementHandlers
});


doc.save('test.pdf');
}

  constructor() { }

  ngOnInit() {
  }

}
